class MemberEntity {
  final String name;
  final String role;

  MemberEntity({required this.name, required this.role});
}
