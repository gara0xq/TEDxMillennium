import 'package:flutter/material.dart';

class AppColors {
  static Color primary = const Color(0xFFf93138);
  static Color secondary = const Color(0xFF171717);
  static Color white = const Color(0xFFfff5f5);
}
